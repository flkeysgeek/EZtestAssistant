#Custom Alert
Função alert() e confirm() customizável. Substituí as funções alert() e confirm() do JavaScript, permitindo customiza-las. Essa aplicação não usa jQuery ou outro framework, somente JavaScript e CSS. Funciona perfeita mente em dispositivos mobile, adaptando-se automaticamente ao tamanho da tela.

##Documentação e exemplos:

[http://www.philippeassis.com/alert-e-confirm-personalizado-sem-jquery](http://www.philippeassis.com/alert-e-confirm-personalizado-sem-jquery)
